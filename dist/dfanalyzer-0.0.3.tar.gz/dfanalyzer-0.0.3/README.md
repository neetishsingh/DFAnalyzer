# DFAnalyzer
This is a python package which helps pyspark community to analyse there data set before concluding any decision out of it.
